# NEBULA:FOG 2026 — Event Summary Report

## Final Rankings

| Rank | Team | Track | Score |
|------|------|-------|-------|
| 1 | AgentRange 🥇 | ROGUE::AGENT | 8.3/10 |
| 2 | DoYouKnowWhatYouBuiltLastSummer 🥈 | ROGUE::AGENT | 8.3/10 |
| 3 | Genomics 🥉 | ROGUE::AGENT | 7.9/10 |
| 4 | Igor | ROGUE::AGENT | 7.5/10 |
| 5 | Starcraft | ROGUE::AGENT | 6.5/10 |
| 6 | TeamKickass | SENTINEL::MESH | 6.3/10 |
| 7 | Kavin | ROGUE::AGENT | 6.1/10 |
| 8 | GossipProblem | ZERO::PROOF | 5.7/10 |
| 9 | WeNeedaName | ROGUE::AGENT | 5.3/10 |
| 10 | KC2 | ROGUE::AGENT | 5.2/10 |
| 11 | Overwatch | ROGUE::AGENT | 4.2/10 |
| 12 | KC | ROGUE::AGENT | 3.8/10 |
| 13 | AgentTrustGateway | ROGUE::AGENT | 3.7/10 |
| 14 | Tobias | ROGUE::AGENT | 3.5/10 |
| 15 | Winston | ROGUE::AGENT | 3.3/10 |
| 16 | RickToday | ROGUE::AGENT | 3.2/10 |
| 17 | Gabo | ROGUE::AGENT | 2.7/10 |
| 18 | ThirdParty | ROGUE::AGENT | 1.9/10 |
| 19 | Ticket Security Incite | ROGUE::AGENT | 1.6/10 |
| 20 | TeamPie | SHADOW::VECTOR | 1.5/10 |
| 21 | MagicThing | ROGUE::AGENT | 1.4/10 |
| 22 | Rick | ROGUE::AGENT | 1.4/10 |
| 23 | Test | ROGUE::AGENT | 1.4/10 |

## Event Statistics

- **Teams scored**: 23
- **Teams with observations**: 25
- **Total observations**: 332
- **Total transcripts**: 239
- **Average score**: 4.4/10
- **Highest score**: AgentRange (8.3)
- **Lowest score**: Test (1.4)

## Deliberation Narrative

NEBULA:FOG 2026 was a study in the gap between ambition and execution, where technical difficulties became the great equalizer. The event's top tier—AgentRange and DoYouKnowWhatYouBuiltLastSummer at 8.3—exists in a quantum state of Schrödinger's excellence: their scores suggest strong work, but the complete absence of observable content means we're judging ghosts. Genomics at 7.9 becomes the de facto winner by virtue of being the highest-scoring team with actual evidence of technical work, showing docker workflows and bioinformatics tooling that at least proved something existed.

The middle tier revealed a hackathon truth: presentation matters as much as code. Teams like Kavin (6.1) and Starcraft (6.5) burned through full 10-minute slots but struggled with audio corruption and visual failures that reduced their demos to archaeological exercises in transcript interpretation. The track diversity—TeamKickass in SENTINEL::MESH, GossipProblem in ZERO::PROOF, TeamPie in SHADOW::VECTOR—showed ambition to tackle different security angles, but the 5.7-6.3 scores suggest these teams couldn't fully realize their visions in the time available. Meanwhile, the supply chain security cluster (WeNeedaName, ThirdParty, ThirdParty-shapor) all attacked the same dependency problem with wildly different outcomes, from 5.3 to 0.0.

The bottom tier is where things get interesting in a darkly comedic way. ThirdParty-shapor's 0.0 despite having the most detailed technical architecture in the entire event is either a cautionary tale about demo functionality trumping design, or evidence of a disqualification that isn't reflected in the data. Teams like Test (1.4) and Lens (0.0) with 11-second demos set the floor for 'we showed up,' while longer failures like Ticket Security Incite (1.6) proved that nine minutes of incomprehensible audio is worse than honest brevity. The event's lesson: in a hackathon, a working demo beats a brilliant architecture, clear audio beats perfect code, and sometimes the best strategy is knowing when to stop talking. These teams built the foundation for future work—the question is whether they'll debug their presentation skills as thoroughly as their code.

## Notable Themes

- Catastrophic presentation technical failures: 15+ teams experienced OBS placeholder screens, muted cameras, or complete video feed loss, suggesting systematic issues with streaming infrastructure or setup guidance
- Audio quality as the great differentiator: Teams with clear audio (Kavin, WeNeedaName, ThirdParty-shapor) could at least communicate ideas despite visual failures, while those with corrupted audio (Igor, Starcraft, Gabo) became incomprehensible regardless of demo length
- Supply chain security convergence: Multiple teams (WeNeedaName, ThirdParty, ThirdParty-shapor) independently tackled npm/dependency security, suggesting this is a recognized pain point, but with wildly divergent execution quality
- Track misalignment: Many ROGUE::AGENT teams built generic security tools (email phishing, social media content moderation) without clear connection to AI agent-specific threats, suggesting either track requirements were unclear or teams pivoted from original ideas
- The 'demo duration paradox': Longer demos (600s) didn't correlate with higher scores—Kavin and Starcraft used full time but scored 6.1-6.5, while Genomics achieved 7.9 in 282s, suggesting judges valued focus over comprehensiveness
- The missing middle: Very few teams scored in the 7.0-8.0 range (only Genomics and Igor), creating a gap between top tier (8.3) and upper-middle (6.5), suggesting judges saw clear quality breaks rather than gradual gradations
- Zero-score mystery: ThirdParty-shapor's 0.0 despite detailed technical architecture suggests either non-functional demos receive no credit regardless of design quality, or undocumented disqualification criteria are in play
- Team naming as signal: Generic names (MagicThing, WeNeedaName, Test) correlated with lower scores, while specific names (AgentTrustGateway, GossipProblem, Starcraft) suggested clearer product vision even when execution failed

---
*Generated by Arbiter AI Judge — NEBULA:FOG 2026*